#include <iostream>
#include <string.h>
using namespace std;
#include "Doctor.h"

int main()
{
    Doctor d1, d2;

    d1.setDoctorDetails(1, (char*)"Dr. Sunil", (char*)"Neurologist");
    d2.setDoctorDetails(2, (char*)"Dr. Yasantha", (char*)"Oncologist");

    d1.setHospital();
    d2.setHospital();

    d1.displayDoctorDetails();
    d2.displayDoctorDetails();

    return 0;
}

